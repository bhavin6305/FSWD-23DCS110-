export const API_KEY="880cba2b766de6617e34ec7cc1e58294"
export const TMDB_BASE_URL='https://api.themoviedb.org/3'